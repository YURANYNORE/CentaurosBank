
package alquilervehiculos;

public class Coche extends Vehiculo {
    protected String PrecioAdicionalCoche = "1.5";
    protected double TotalPagarAlquilerCoche=0;
    
 public Coche () {
    tipoVehiculo = "Coche";
 }
    
public Coche (String tipo, double costo){
    super (tipo,costo); 
}
    
public void calcularAlquilerCoche () {
    TotalPagarAlquilerCoche= diaAlquiler(PrecioAdicionalCoche+costoAlquilerDia);
    
}

    private double diaAlquiler(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
    

