
package alquilervehiculos;

public class Camiones extends Vehiculo {
    protected String PrecioAdicionalFurgonesCarga = "20";
    protected String PrecioMaximoAutorizadoTonelada = "3";
    protected String PrecioMaximoCamiones= "40";
    protected double TotalPagarAlquilerCamiones=0;
   
    
 public Camiones () {
    tipoVehiculo = "Microbuses";
 }
    
public Camiones (String tipo, double costo){
    super (tipo,costo); 
}
    
public void calcularAlquilerCamiones () {
TotalPagarAlquilerCamiones=(diaAlquiler*costoAlquilerDia)+(PrecioAdicionalFurgonesCarga*PrecioMaximoAutorizadoTonelada)+TotalPagarAlquilerCamiones; 
    
}

    private String diaAlquiler(String String) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}