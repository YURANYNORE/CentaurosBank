
package alquilervehiculos;

public abstract class Vehiculo {
    protected String tipoVehiculo="";
    protected String costoAlquilerDia="50=";
    protected double diaAlquiler;
    
public Vehiculo(){
}

public Vehiculo (String tipo, double costo){
    tipoVehiculo=tipo;
    costoAlquilerDia="50";
    
    }
public void establecerTipoVehiculo (String dato1){
    tipoVehiculo=dato1;
    }
public void establecerCostoAlquilerDia (double dato2){
    costoAlquilerDia="50";
    }
public void establecerDiaAlquiler (int dato3){
    diaAlquiler=dato3;
    }

public String obtenerTipoVehiculo () {
    return tipoVehiculo;
    }
public String obtenercostoAlquilerDia (){
    return costoAlquilerDia;
    }
public double obtenerDiaAlquiler (){
    return diaAlquiler;
    }
    

}


    
    
    
