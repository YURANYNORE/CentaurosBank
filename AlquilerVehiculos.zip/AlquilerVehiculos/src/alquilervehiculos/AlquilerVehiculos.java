/*
 */
package alquilervehiculos;

import java.util.Scanner;
/**
 */
public class AlquilerVehiculos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String menu= "";
       
       Scanner captura = new Scanner (System.in);
       Coche miCoche = new Coche ();
       Microbuses miMicrobuses = new Microbuses ();
       FurgonesCarga miFurgonesCarga = new FurgonesCarga ();
       Camiones miCamiones = new Camiones ();
     
       System.out.println("SELECCIONE LA CATEGORIA DEL VEHICULO QUE DESEA ALQUILAR");
       System.out.println ("Digite Opcion 1 para Coche");
       System.out.println ("Digite Opcion 1 para Microbuses");
       System.out.println ("Digite Opcion 1 para FurgonesCarga");
       System.out.println ("Digite Opcion 1 para Camiones");
       System.out.println ("_______________________________________________________");
       System.out.println ("CALCULO DEL VALOR DE ALQUILER DEL VEHICULO");
       
    switch (menu) 
            {
                case "1":
                    //System.out.printf("El costo del Alquiler del Coche es %s\n",miCoche.calcularAlquilerCoche());
                   // System.out.printf("El costo del Alquiler por dia es #.2f\n", miCoche.costoAlquilerDia ());//
                    System.out.printf("___________________________________");
               System.out.println ("Digite  Dias Alquilados");
               
               break; 
               case "2":
                    System.out.printf("El costo del Alquiler del Microbuses es %s\n",calcularAlquilerMicrobuses());
                   // System.out.printf("El costo del Alquiler por dia es #.2f\n", miCoche.costoAlquilerDia ());//
                    System.out.printf("___________________________________");
               System.out.println ("Digite  Dias Alquilados");
               
               break;
               case "3":
                    System.out.printf("El costo del Alquiler del FurgonesCarga es %s\n",calcularAlquilerFurgonesCarga());
                   // System.out.printf("El costo del Alquiler por dia es #.2f\n", miCoche.costoAlquilerDia ());//
                    System.out.printf("___________________________________");
               System.out.println ("Digite  Dias Alquilados");
               
               break;
               case "4":
                    System.out.printf("El costo del Alquiler del Camiones es %s\n",calcularAlquilerCamiones());
                   // System.out.printf("El costo del Alquiler por dia es #.2f\n", miCoche.costoAlquilerDia ());//
                    System.out.printf("___________________________________");
               System.out.println ("Digite  Dias Alquilados");
            
    break;
    
                default:
    System.out.println ("No digito una opción válida ");
    }

     

