
package alquilervehiculos;

public class Microbuses extends Vehiculo {
    protected String PrecioAdicionalMicrobuses = "2";
    protected String PrecioAdicionalCoche = "1.5";
    protected double TotalPagarAlquilerMicrobuses=0;
   
    
 public Microbuses () {
    tipoVehiculo = "Microbuses";
 }
    
public Microbuses (String tipo, double costo){
    super (tipo,costo); 
}
    
public void calcularAlquilerMicrobuses () {
    TotalPagarAlquilerMicrobuses=[diaAlquiler(PrecioAdicionalCoche*costoAlquilerDia)+PrecioAdicionalMicrobuses]; 
    
}

    private String diaAlquiler(String String) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
    