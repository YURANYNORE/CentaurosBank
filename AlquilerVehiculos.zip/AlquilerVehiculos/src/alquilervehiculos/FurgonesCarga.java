
package alquilervehiculos;

public class FurgonesCarga extends Vehiculo {
    protected String PrecioAdicionalFurgonesCarga = "20";
    protected String PrecioMaximoAutorizadoTonelada = "3";
    protected double TotalPagarAlquilerFurgonesCarga=0;
   
    
 public FurgonesCarga () {
    tipoVehiculo = "Microbuses";
 }
    
public FurgonesCarga (String tipo, double costo){
    super (tipo,costo); 
}
    
public void calcularAlquilerFurgonesCarga () {
TotalPagarAlquilerFurgonesCarga=(diaAlquiler*costoAlquilerDia)+(PrecioAdicionalFurgonesCarga*PrecioMaximoAutorizadoTonelada); 
    
}

    private String diaAlquiler(String String) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}